# Symptoms IQ — Vercel deployment

This is a single, self-contained static HTML file (`index.html`) — no build step,
no dependencies, no server code. Vercel can host it as-is.

## Deploy via the Vercel dashboard (no CLI needed)
1. Go to https://vercel.com/new
2. Choose "Deploy" → drag-and-drop this folder (or just `index.html`) onto the page,
   or push it to a GitHub repo first and import that repo.
3. Framework preset: choose "Other" (or leave as detected for a static file).
4. Click Deploy. Vercel will give you a live URL in under a minute.

## Deploy via the Vercel CLI
```
npm i -g vercel
cd vercel-deploy
vercel --prod
```
Follow the prompts (link to a new project, accept defaults). It will print the
live URL when done.

## Notes
- All persisted data (bookmarks, theme, text size, emergency-country choice,
  feedback submissions) is stored in the visitor's own browser via
  localStorage — there is no backend and nothing is sent anywhere.
- Deep links to individual symptoms work out of the box via the URL hash
  (e.g. yoursite.vercel.app/#symptom/panic-attack); no server routing needed.
- If you later add a custom domain in Vercel, nothing in the file needs to
  change — it's fully relative/self-contained.
